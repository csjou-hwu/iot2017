pin=0
pio.mode(pin, gpio.OUTPUT)

lighton=0
tmr.alarm(0,1000,1,function()
if lighton==0 then 
    lighton=1 
    gpio.write(pin, gpio.LOW)
    --led(512,512,512) 
    -- 512/1024, 50% duty cycle
else 
    lighton=0 
    --led(0,0,0) 
    gpio.write(pin, gpio.HIGH)
end 
end)
