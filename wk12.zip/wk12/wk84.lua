print("hello world")  
pin=0
gpio.mode(pin, gpio.OUTPUT)
gpio.write(pin, gpio.LOW)