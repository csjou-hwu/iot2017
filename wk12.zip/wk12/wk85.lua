tmr.alarm(0, 1000, 1, function()  
    print("hello world")
    end)