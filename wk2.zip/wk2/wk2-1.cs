using System;
namespace 命名空間1
{
    class 類別1
    {
        public static void Main()
        {
            Console.WriteLine("Hello 092012");
        }
    }
}