using System;
using System.Windows.Forms;
namespace 命名空間1
{
    class 類別1
    {
        public static void Main()
        {
            Console.WriteLine("Hello 092012");
            表單類別 表單物件 = new 表單類別();
            Button 按鈕物件 = new Button();
            按鈕物件.Click += new EventHandler(按一下);
            表單物件.Controls.Add(按鈕物件);
            表單物件.ShowDialog();
        }
        private static void 按一下(Object Obj, EventArgs e)
        {
            ((Button)Obj).Text = "092012 Click";
        }
    }
    class 表單類別 : System.Windows.Forms.Form
    {

    }
}