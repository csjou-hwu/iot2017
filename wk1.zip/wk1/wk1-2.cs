using System;
using System.Windows.Forms;
namespace 命名空間1
{
    class 類別1
    {
        public static void Main()
        {
            Application.Run(new 類別2());            
        }
    }
    class 類別2 : Form 
    {
            public 類別2()
            {
                Button 按鈕物件 = new Button();
                this.Controls.Add(按鈕物件);
            }
    }
    
}