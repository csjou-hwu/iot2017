using System;
namespace N1
{
	class C1
	{
		public static void Main()
		{
			Console.WriteLine("Hello");
		}
	}
}