using System;
using System.Windows.Forms;
namespace N1
{
    class C1
    {
        public static void Main()
        {
            Console.WriteLine("Hello 092012");
            C2 form1 = new C2();
            Button B1 = new Button();
            form1.Controls.Add(B1);
            form1.ShowDialog();
        }
    }
    class C2 : Form 
    {

    }
    
}