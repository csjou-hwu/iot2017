-- print the first line of 'init.lua'
if file.open("test.txt", "r") then
  --print(file.read('\n'))
  for i=0, 2, 1
  do
  print(file.readline())
  end
  --print(file.readline())
  --print(file.readline())
  file.close()
  else
  print("File not found.")
end

