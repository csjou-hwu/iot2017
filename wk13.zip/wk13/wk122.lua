-- wk122.lua
for i=10,1,-1 
do 
   print(i) 
end