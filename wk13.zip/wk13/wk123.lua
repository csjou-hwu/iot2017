-- a=10
if file.open("index.htm", "r") then
  while( true )
  do
      b = file.readline()
      if b == nil then break end
      print(b)
  end
end
