using System;
using System.IO;
namespace wk141
{
    class C1
    {
        static void Main()
        {
            using (StreamWriter sw = new StreamWriter("initxx.lua"))
            {
            using (StreamReader sr = new StreamReader("init0.lua")) 
            {
                string line;
                // Read and display lines from the file until the end of 
                // the file is reached.
                while ((line = sr.ReadLine()) != null) 
                {
                    sw.WriteLine(line);
                }
            }
            using (StreamReader sr = new StreamReader("math.html")) 
            {
                string line;
                // Read and display lines from the file until the end of 
                // the file is reached.
                while ((line = sr.ReadLine()) != null) 
                {
                    // --conn:send("<h1> Hello, NodeMcu.</h1>")
                    line = "conn:send(\"" + line + "\")";
                    sw.WriteLine(line);
                }
            }
            sw.WriteLine("end)");
            sw.WriteLine("end)");
            }
        }
    }
}
